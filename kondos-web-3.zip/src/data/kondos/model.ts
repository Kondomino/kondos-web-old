export class Model  
{
    id?: Number;
    createdAt?: string;
    updatedAt?: string;
}